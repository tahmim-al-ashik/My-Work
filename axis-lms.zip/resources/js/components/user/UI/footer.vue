<template>
<div>
    <!-- Footer section -->
    <footer class="footer_section">
        <div class="tork-container">
            <div class="tork-row">
                <div class="tork-col-md-4">
                    <div class="details">
                        <div class="logo">
                            <img :src="logo" alt="">
                        </div>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                    </div>
                </div>
                <div class="tork-col-md-2">
                    <h4>Mobile app</h4>
                    <ul>
                        <li><a href="#">Features</a></li>
                        <li><a href="#">Live share</a></li>
                        <li><a href="#">Video record</a></li>
                    </ul>
                </div>
                <div class="tork-col-md-2">
                    <h4>Useful Links</h4>
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li><a href="#">How to Enroll</a></li>
                    </ul>
                </div>
                <div class="tork-col-md-2">
                    <h4>Company</h4>
                    <ul>
                        <li><a href="#">About us</a></li>
                        <li><a href="#">Contact us</a></li>
                        <li><a href="#">History</a></li>
                    </ul>
                </div>
            </div>
            <!-- copyright -->
            <div class="copyright">
                <div class="tork-d-flex tork-justify-c-space-between tork-items-center">
                    <p>&copy; All Copyright, <a href="#">Synapse Medical Academy</a>. 2021</p>
                    <ul class="social_links tork-d-flex">
                        <li><a href="#"><span class="icon-facebook-square"></span></a></li>
                        <li><a href="#"><span class="icon-twitter-square"></span></a></li>
                        <li><a href="#"><span class="icon-instagram-square"></span></a></li>
                        <li><a href="#"><span class="icon-linkedin"></span></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    <div class="circle_1"></div>
    <div class="circle_2"></div>
</div>
</template>

<script>
import logo from '../../../../images/logo.png';
export default {

    data(){
        return{
            logo:logo,
        }
    }
}
</script>

<style scoped>
.tork-text-primary {
  color: #662d91 !important;
}

.tork-text-primary-gradient {
  color: linear-gradient(234.06deg, rgba(255, 255, 255, 0.2) 0%, rgba(255, 255, 255, 0.6) 100%) !important;
}

.tork-text-secondary {
  color: #6c757d !important;
}

.tork-text-success {
  color: #198754 !important;
}

.tork-text-info {
  color: #bea7cf !important;
}

.tork-text-warning {
  color: #ffce31 !important;
}

.tork-text-danger {
  color: #e35a5a !important;
}

.tork-text-light {
  color: #d7d7d7 !important;
}

.tork-text-white {
  color: #ffffff !important;
}

.tork-text-dark {
  color: #000000 !important;
}

.tork-bg-primary {
  background: #662d91 !important;
}

.tork-bg-primary-gradient {
  background: linear-gradient(234.06deg, rgba(255, 255, 255, 0.2) 0%, rgba(255, 255, 255, 0.6) 100%) !important;
}

.tork-bg-secondary {
  background: #6c757d !important;
}

.tork-bg-success {
  background: #198754 !important;
}

.tork-bg-info {
  background: #bea7cf !important;
}

.tork-bg-warning {
  background: #ffce31 !important;
}

.tork-bg-danger {
  background: #e35a5a !important;
}

.tork-bg-light {
  background: #d7d7d7 !important;
}

.tork-bg-white {
  background: #ffffff !important;
}

.tork-bg-dark {
  background: #000000 !important;
}

.footer_section {
  padding-top: 9rem;
  background: linear-gradient(234.06deg, rgba(255, 255, 255, 0.2) 0%, rgba(255, 255, 255, 0.6) 100%);
}

.footer_section .details .logo {
  width: 14rem;
  margin-bottom: 1rem;
}

.footer_section .details .logo img {
  width: 100%;
  height: auto;
}

.footer_section .details p {
  font-size: 0.75rem;
  color: #bea7cf;
  font-weight: 400;
  line-height: 1.3rem;
}

.footer_section h4 {
  font-size: 1.2rem;
  margin-bottom: 1.6rem;
  color: #662d91;
  font-weight: 600;
}

.footer_section ul li {
  margin-top: .5rem;
}

.footer_section ul li a {
  font-size: .85rem;
  font-weight: 500;
  color: #bea7cf;
}

.footer_section ul li a:hover {
  color: #662d91;
}

.footer_section .copyright {
  margin-top: 4rem;
  padding: 1rem 0;
  border-top: 1px solid rgba(96, 110, 180, 0.2);
}

.footer_section .copyright p {
  font-size: .75rem;
}

.footer_section .copyright p a {
  font-weight: 500;
  color: #662d91;
}

.footer_section .copyright .social_links li a {
  font-size: 1.8rem;
  color: #662d91;
  margin-left: 0.8rem;
}

.footer_section .copyright .social_links li a:hover {
  color: #000000;
}
/*# sourceMappingURL=footer_section.css.map */
</style>
