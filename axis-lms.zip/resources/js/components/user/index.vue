<template>

  <main>
         <!-- Hero Section  -->
         <section class="hero_section">
             <div class="tork-container">
                 <div class="tork-row">
                     <div class="tork-col-md-6 tork-d-flex tork-items-center">
                         <div class="hero_text_inner">
                             <h3 class="sub_heading">World Best Online </h3>
                             <h1 class="heading">Learning Platform</h1>
                             <p class="description">
                                 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut magnis morbi eu libero, velit id sed. Tortor
                                 sed gravida nisl pretium mauris, vitae.
                             </p>
                             <a href="#" class="hero_btn tork-btn tork-btn-primary">Go to Classes</a>
                         </div>
                     </div>
                     <div class="tork-col-md-6">
                         <div class="hero_img">
                            <img :src="headerImage" alt="">
                         </div>
                     </div>
                 </div>
             </div>
         </section>
         <!-- End: Hero Section  -->

          <!-- Feature section -->
         <section class="feature_section">
             <div class="tork-container">
                 <div class="feature_inner tork-bg-white tork-rounded-5">
                     <div class="tork-row">
                         <div class="tork-col-md-4">
                             <div class="tork-d-flex tork-items-center">
                                 <div class="icon_img">
                                  <img :src="classIcon" alt="">
                                 </div>
                                 <div class="info">
                                     <h2>Class Materials</h2>
                                     <p>Explore a variety of fresh topics.</p>
                                 </div>
                             </div>
                         </div>
                         <div class="tork-col-md-4">
                             <div class="tork-d-flex tork-items-center">
                                 <div class="icon_img">
                                  <img :src="classIcon2" alt="">
                                 </div>
                                 <div class="info">
                                     <h2>Class Materials</h2>
                                     <p>Explore a variety of fresh topics.</p>
                                 </div>
                             </div>
                         </div>
                         <div class="tork-col-md-4">
                             <div class="tork-d-flex tork-items-center">
                                 <div class="icon_img">
                                  <img :src="classIcon3" alt="">
                                 </div>
                                 <div class="info">
                                     <h2>Class Materials</h2>
                                     <p>Explore a variety of fresh topics.</p>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </section>
         <!-- End: Feature section -->

    <!-- Courses Section -->
         <section class="courses_section tork-position-relative">
             <div class="tork-container">
                 <div class="course_heading tork-text-center">
                     <h2 class="tork-text-dark">Our Populer <span class="tork-text-primary">Courses</span></h2>
                     <p class="description tork-text-info">Lorem Ipsum is simply dummy text of the printing and typesetting
                         industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown
                         printer took a galley of type and scrambled it to make a type specimen book. It has survived.</p>
                 </div>
                 <!-- Filter nav -->
                <div class="filter_nav">

                  <ul class="tork-d-flex filter_item" >
                     <li :class="selectedId === 0 ? 'active': '' " data-filter=".all"><a @click="ResetselectedId()">All Course</a></li>
                    <li :class="selectedId === category.id ? 'active': '' " data-filter=".sociology" v-for="(category , index) in categories" :key="index"><a @click="setName(category.category_name,category.id)">{{category.category_name}}</a></li>
                  </ul>
                </div>
                 <!-- courses items -->
                 <div class="tork-row course_items">

                    <!--all courses list-->

                      <div v-if="selectedId === 0" class="computer sociology tork-col-md-4" v-for="(all_course , index) in courses" :key="index.id">
                         <div class="course_card">
                             <div class="course_item">
                                 <div class="course_thumb">
                                    <img :src="all_course.banner" alt="">
                                 </div>
                                 <div class="course_info">
                                     <a href="#">
                                         <h3>{{ all_course.title}}</h3>
                                     </a>
                                     <div class="sub_info tork-d-flex tork-justify-c-space-between">
                                         <span>{{ all_course.grade }} | {{ all_course.chapter }}</span>
                                         <div class="rating tork-d-flex">
                                             <span class="icon-star"></span>
                                             <span class="icon-star"></span>
                                             <span class="icon-star"></span>
                                             <span class="icon-star"></span>
                                             <span class="icon-star inactive"></span>
                                             <span class="count_rating">{{all_course.overall_review}}</span>
                                         </div>
                                     </div>
                                     <!-- price -->
                                     <div class="price">
                                         <h4 class="tork-d-inline-block">{{all_course.offer_price}}</h4>
                                         <del class="tork-d-inline-block">{{ all_course.regular_price }}</del>
                                     </div>
                                 </div>
                             </div>
                             <div class="course_hover">
                                 <div class="course_info">
                                     <router-link :to="{name:'course_details',params:{id:all_course.id}}">
                                         <h3>{{ all_course.title}}</h3>
                                     </router-link>
                                     <div class="sub_info tork-d-flex tork-justify-c-space-between">
                                         <span>{{ all_course.grade }} | {{ all_course.chapter }}</span>
                                         <div class="rating tork-d-flex">
                                             <span class="icon-star"></span>
                                             <span class="icon-star"></span>
                                             <span class="icon-star"></span>
                                             <span class="icon-star"></span>
                                             <span class="icon-star inactive"></span>
                                             <span class="count_rating">{{all_course.overall_review}}</span>
                                         </div>
                                     </div>
                                     <!-- price -->
                                     <div class="price">
                                         <h4 class="tork-d-inline-block">{{all_course.offer_price_price}}</h4>
                                         <del class="tork-d-inline-block">{{ all_course.regular_price }}</del>
                                     </div>
                                 </div>
                                 <p class="course_description">
                                     {{ all_course.description}}
                                 </p>
                                 <div class="action_btn tork-d-flex tork-justify-c-space-between">
                                     <router-link :to="{name:'course_details',params:{id:all_course.id}}" class="tork-btn tork-btn-primary tork-rounded-pill">Course Preview</router-link>
                                     <a href="#" @click="courseStorage(index)" class="tork-btn tork-btn-outline-primary tork-rounded-pill">Enroll Now</a>
                                 </div>
                             </div>
                         </div>
                     </div>
                    <!--end lists --->




                     <div v-if="selectedId > 0" class="computer sociology tork-col-md-4" v-for="(course , index) in filterCourse" :key="index.id">
                         <div class="course_card">
                             <div class="course_item">
                                 <div class="course_thumb">
                                    <img :src="course.banner" alt="">
                                 </div>
                                 <div class="course_info">
                                     <a href="#">
                                         <h3>{{ course.title}}</h3>
                                     </a>
                                     <div class="sub_info tork-d-flex tork-justify-c-space-between">
                                         <span>{{ course.grade }} | {{ course.chapter }}</span>
                                         <div class="rating tork-d-flex">
                                             <span class="icon-star"></span>
                                             <span class="icon-star"></span>
                                             <span class="icon-star"></span>
                                             <span class="icon-star"></span>
                                             <span class="icon-star inactive"></span>
                                             <span class="count_rating">{{course.overall_review}}</span>
                                         </div>
                                     </div>
                                     <!-- price -->
                                     <div class="price">
                                         <h4 class="tork-d-inline-block">{{course.offer_price}}</h4>
                                         <del class="tork-d-inline-block">{{ course.regular_price }}</del>
                                     </div>
                                 </div>
                             </div>
                             <div class="course_hover">
                                 <div class="course_info">
                                     <router-link :to="{name:'course_details',params:{id:course.id}}">
                                         <h3>{{ course.title}}</h3>
                                     </router-link>
                                     <div class="sub_info tork-d-flex tork-justify-c-space-between">
                                         <span>{{ course.grade }} | {{ course.chapter }}</span>
                                         <div class="rating tork-d-flex">
                                             <span class="icon-star"></span>
                                             <span class="icon-star"></span>
                                             <span class="icon-star"></span>
                                             <span class="icon-star"></span>
                                             <span class="icon-star inactive"></span>
                                             <span class="count_rating">{{course.overall_review}}</span>
                                         </div>
                                     </div>
                                     <!-- price -->
                                     <div class="price">
                                         <h4 class="tork-d-inline-block">{{course.offer_price_price}}</h4>
                                         <del class="tork-d-inline-block">{{ course.regular_price }}</del>
                                     </div>
                                 </div>
                                 <p class="course_description">
                                     {{ course.description}}
                                 </p>
                                 <div class="action_btn tork-d-flex tork-justify-c-space-between">
                                     <router-link :to="{name:'course_details',params:{id:course.id}}" class="tork-btn tork-btn-primary tork-rounded-pill">Course Preview</router-link>
                                     <a href="#" @click="courseStorage(index)" class="tork-btn tork-btn-outline-primary tork-rounded-pill">Enroll Now</a>
                                 </div>
                             </div>
                         </div>
                     </div>



                 </div>

             </div>
             <div class="circle_1"></div>
             <div class="circle_2"></div>
         </section>
         <!-- End: Courses Section -->

    <!-- Testimonial Section -->
    <section class="testimonial_section tork-position-relative">
      <div class="tork-container">
        <div class="testimonial_heading tork-text-center">
          <h2 class="tork-text-dark">Whats Our <span class="tork-text-primary">Customer Says</span></h2>
          <p class="description tork-text-info">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived.</p>
        </div>
        <div class="tork-row">
          <div class="tork-col-md-4">
            <div class="testimonial_item tork-d-flex">
              <div class="client_img">
                <img src="" alt="">
              </div>
              <div class="review">
                <h4 class="name">John WIck</h4>
                <span class="position">9th Grade Student</span>
                <p class="comments">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown.</p>
              </div>
              <div class="quote tork-position-absolute">
                <img src="" alt="">
              </div>
            </div>
          </div>
          <div class="tork-col-md-4">
            <div class="testimonial_item middle tork-d-flex">
              <div class="client_img">
                <img src="" alt="">
              </div>
              <div class="review">
                <h4 class="name">John WIck</h4>
                <span class="position">9th Grade Student</span>
                <p class="comments">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown.</p>
              </div>
              <div class="quote tork-position-absolute">
                <img src="" alt="">
              </div>
            </div>
          </div>
          <div class="tork-col-md-4">
            <div class="testimonial_item tork-d-flex">
              <div class="client_img">
                <img src="" alt="">
              </div>
              <div class="review">
                <h4 class="name">John WIck</h4>
                <span class="position">9th Grade Student</span>
                <p class="comments">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown.</p>
              </div>
              <div class="quote tork-position-absolute">
                <img src="" alt="">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="circle_1"></div>
      <div class="circle_2"></div>
    </section>
    <!-- End: Testimonial Section -->

    <!-- countdown section -->
    <section class="countdown_section">
      <div class="tork-container">
        <div class="countdown_inner tork-bg-white tork-rounded-5">
          <div class="tork-row">
            <div class="tork-col-md-4">
              <div class="tork-d-flex tork-items-center tork-justify-c-center">
                <div class="icon_img">
                  <img src="" alt="">
                </div>
                <div class="info">
                  <h2>100+</h2>
                  <p>Expart Teacher</p>
                </div>
              </div>
            </div>
            <div class="tork-col-md-4">
              <div class="tork-d-flex tork-items-center tork-justify-c-center">
                <div class="icon_img">
                  <img src="" alt="">
                </div>
                <div class="info">
                  <h2>9000+</h2>
                  <p>Srudents Enroll</p>
                </div>
              </div>
            </div>
            <div class="tork-col-md-4">
              <div class="tork-d-flex tork-items-center tork-justify-c-center">
                <div class="icon_img">
                  <img src="" alt="">
                </div>
                <div class="info">
                  <h2>500+</h2>
                  <p>Parents Join with us</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End: countdown section -->

    <!-- News letter Section -->
    <section class="newsletter_section tork-position-relative">
      <div class="tork-container">
        <div class="newsletter_heading tork-text-center">
          <h2 class="tork-text-dark">Subscribe to Get <span class="tork-text-primary">Our Newsletter</span></h2>
          <p class="description tork-text-info">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived.</p>
      </div>
      <div class="tork-row">
        <div class="newsletter_col tork-col-md-6">
          <div class="newsletter_feild tork-d-flex">
            <input type="email" class="tork-form-control newsletter_input" placeholder="Enter your Email">
            <button class="tork-btn tork-btn-primary newsletter_btn">Subscribe</button>
          </div>
        </div>
      </div>
      </div>
      <div class="circle_1"></div>
      <div class="circle_2"></div>
    </section>
    <!-- End: News letter Section -->
  </main>
</template>

<script>
import headerImage from '../../../images/home-page-header-avater.png';
import classIcon from '../../../images/about-course-icon-6.png'
import classIcon2 from '../../../images/about-course-icon-5.png'
import classIcon3 from '../../../images/about-course-icon-2.png'
export default {
    data(){
        return{
            categories:[],
            category_name:'',
            selectedId:0,
            headerImage:headerImage,
            classIcon:classIcon,
            classIcon3:classIcon3,
            classIcon2:classIcon2,
            courses:[],

        }
    },
    created() {
        axios.get('/api/courses')
        .then((response) =>{
            this.courses = response.data

        })

        axios.get('/api/category')
        .then((response)=>{
          this.categories = response.data
        })
    },

    methods:{
        courseStorage(index){
            var course_iteam  = {course_title: this.courses[index].title,banner:this.courses[index].banner,id:this.courses[index].id, price:this.courses[index].offer_price_price}
            var store = JSON.parse(localStorage.getItem("enroll_courses")) || [];
            store.push(course_iteam);

            localStorage.setItem("enroll_courses", JSON.stringify(store));

            Toast.fire({
                icon: 'success',
                title: 'enrolled  successfully'
            })
            this.$router.push('/check-out')
        },
        setName(name,id){
          this.category_name = name;
          this.selectedId = id;
        },
        ResetselectedId(){
          this.selectedId =0;
        }
    },

     computed:{
            filterCourse(){
                return this.courses.filter(course => {
                   return String(course.category_id) == String(this.selectedId)
                })
            }
        },

}
</script>

<style scoped>
.tork-text-primary {
  color: #662d91 !important;
}

.tork-text-primary-gradient {
  color: linear-gradient(234.06deg, rgba(255, 255, 255, 0.2) 0%, rgba(255, 255, 255, 0.6) 100%) !important;
}

.tork-text-secondary {
  color: #6c757d !important;
}

.tork-text-success {
  color: #198754 !important;
}

.tork-text-info {
  color: #bea7cf !important;
}

.tork-text-warning {
  color: #ffce31 !important;
}

.tork-text-danger {
  color: #e35a5a !important;
}

.tork-text-light {
  color: #d7d7d7 !important;
}

.tork-text-white {
  color: #ffffff !important;
}

.tork-text-dark {
  color: #000000 !important;
}

.tork-bg-primary {
  background: #662d91 !important;
}

.tork-bg-primary-gradient {
  background: linear-gradient(234.06deg, rgba(255, 255, 255, 0.2) 0%, rgba(255, 255, 255, 0.6) 100%) !important;
}

.tork-bg-secondary {
  background: #6c757d !important;
}

.tork-bg-success {
  background: #198754 !important;
}

.tork-bg-info {
  background: #bea7cf !important;
}

.tork-bg-warning {
  background: #ffce31 !important;
}

.tork-bg-danger {
  background: #e35a5a !important;
}

.tork-bg-light {
  background: #d7d7d7 !important;
}

.tork-bg-white {
  background: #ffffff !important;
}

.tork-bg-dark {
  background: #000000 !important;
}

.hero_section {
  padding: 9rem 0;
  background: url("../images/home-header-Pattern.png");
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center center;
}

.hero_section .hero_text_inner .sub_heading {
  font-size: 1.5rem;
  font-weight: 600;
  letter-spacing: 3px;
  text-transform: capitalize;
  color: #000000;
  line-height: 1.8rem;
}

.hero_section .hero_text_inner .heading {
  font-size: 2.4rem;
  line-height: 2rem;
  font-weight: 700;
  text-transform: capitalize;
  color: #662d91;
  margin: 1rem 0;
}

.hero_section .hero_text_inner .description {
  font-size: 1rem;
  color: #bea7cf;
  font-weight: 400;
  line-height: 1.6rem;
  margin-top: 1.3rem;
}

.hero_section .hero_text_inner .hero_btn {
  border-radius: 1rem;
  padding: .6rem 2rem;
  font-size: 1rem;
  font-weight: 500;
  margin-top: 1rem;
  letter-spacing: 1px;
  -webkit-box-shadow: 0px 6px 11px -3px rgba(102, 45, 145, 0.39);
          box-shadow: 0px 6px 11px -3px rgba(102, 45, 145, 0.39);
}

.hero_section .hero_img img {
  -o-object-fit: cover;
     object-fit: cover;
  width: 100%;
  height: auto;
}

.feature_section {
  padding: 1rem 0;
}

.feature_section .feature_inner {
  padding: 2rem 4rem;
  -webkit-box-shadow: 0px 6px 25px -10px rgba(102, 45, 145, 0.39);
          box-shadow: 0px 6px 25px -10px rgba(102, 45, 145, 0.39);
}

.feature_section .feature_inner .icon_img {
  width: 3rem;
  margin-right: 1rem;
}

.feature_section .feature_inner .icon_img img {
  width: 100%;
  height: auto;
}

.feature_section .feature_inner .info h2 {
  font-size: 1.3rem;
  line-height: 2rem;
  font-weight: 600;
  color: #662d91;
}

.feature_section .feature_inner .info p {
  font-size: 0.75rem;
  font-weight: 400;
  color: #858585;
  list-style: 1.7rem;
}

.courses_section {
  padding: 4rem 0;
}

.courses_section .course_heading {
  margin-bottom: 2rem;
}

.courses_section .course_heading h2 {
  font-size: 2.3rem;
  font-weight: 600;
  line-height: 2rem;
  margin: 1rem 0;
}

.courses_section .course_heading .description {
  font-size: 0.85rem;
  line-height: 1.3rem;
  font-weight: 400;
  text-align: center;
  margin: 1.6rem 0;
}

.courses_section .filter_nav {
  margin-top: 2rem;
  margin-bottom: 1rem;
}

.courses_section .filter_nav ul {
  -webkit-box-pack: center;
      -ms-flex-pack: center;
          justify-content: center;
}

.courses_section .filter_nav ul li {
  margin: 0 2rem;
  padding: 0.2rem;
  cursor: pointer;
  color: #bea7cf;
  font-size: 1rem;
  font-weight: 500;
  border-bottom: 2px solid transparent;
  -webkit-transition: border 0.6s;
  transition: border 0.6s;
  text-transform: capitalize;
}

.courses_section .filter_nav ul li:hover {
  color: #662d91;
  border-color: #662d91;
}

.courses_section .filter_nav ul .active {
  color: #662d91;
  border-color: #662d91;
}

.courses_section .course_items .tork-col-md-4 {
  margin-top: 2rem;
}

.courses_section .course_items .course_item {
  overflow: hidden;
  border-radius: 1rem;
  -webkit-transition: 0.3s ease-in-out;
  transition: 0.3s ease-in-out;
}

.courses_section .course_items .course_item .course_thumb {
  -webkit-box-shadow: 0px 5px 48px -9px rgba(102, 45, 145, 0.39);
          box-shadow: 0px 5px 48px -9px rgba(102, 45, 145, 0.39);
  border-radius: 1rem 1rem 0 0;
  overflow: hidden;
  margin: 0 0.7rem;
  position: relative;
  z-index: 5;
}

.courses_section .course_items .course_item .course_thumb img {
  width: 100%;
  height: auto;
}

.courses_section .course_items .course_item .course_info {
  background-color: #ffffff;
  padding: 1.5rem 1.2rem;
  border-radius: 1rem;
  margin-top: -1rem;
  z-index: 6;
  position: relative;
  padding-bottom: 2rem;
  padding-top: 2.4rem;
}

.courses_section .course_card {
  position: relative;
  overflow: hidden;
}

.courses_section .course_card .course_info h3 {
  font-size: 1.3rem;
  color: #662d91;
  font-weight: 600;
  line-height: 1.8rem;
}

.courses_section .course_card .course_info .sub_info {
  margin: 1rem 0;
}

.courses_section .course_card .course_info .sub_info span {
  color: #bea7cf;
  font-size: 0.75rem;
}

.courses_section .course_card .course_info .sub_info .rating span {
  font-size: 1rem;
  color: #ffce31;
  margin-left: 0.2rem;
}

.courses_section .course_card .course_info .sub_info .rating span:first-child {
  margin-left: 0;
}

.courses_section .course_card .course_info .sub_info .rating .inactive {
  color: #bea7cf;
}

.courses_section .course_card .course_info .sub_info .rating .count_rating {
  color: #bea7cf;
  font-weight: 500;
  font-size: 0.9rem;
  line-height: 1rem;
}

.courses_section .course_card .course_info .price {
  margin-top: 1rem;
}

.courses_section .course_card .course_info .price h4 {
  font-size: 1.2rem;
  color: #662d91;
  font-weight: 600;
  text-transform: uppercase;
}

.courses_section .course_card .course_info .price del {
  color: #bea7cf;
  font-size: 0.85rem;
}

.courses_section .course_card .course_hover {
  position: absolute;
  top: 100%;
  left: 0;
  background: linear-gradient(234.06deg, rgba(255, 255, 255, 0.2) 0%, rgba(255, 255, 255, 0.6) 100%);
  border: 3px solid rgba(255, 255, 255, 0.568);
  padding: 1rem;
  -webkit-box-shadow: 0px 20px 20px -12px rgba(189, 189, 189, 0.1);
          box-shadow: 0px 20px 20px -12px rgba(189, 189, 189, 0.1);
  border-radius: 1rem;
  -webkit-transition: 0.6s;
  transition: 0.6s;
  z-index: 7;
}

.courses_section .course_card .course_hover .course_description {
  font-size: 0.75rem;
  color: #bea7cf;
  line-height: 1.25rem;
  margin: 1rem 0;
}

.courses_section .course_card .course_hover .action_btn {
  margin-top: 2rem;
  margin-bottom: 1rem;
}

.courses_section .course_card .course_hover .action_btn a {
  font-size: 0.9rem;
  font-weight: 600;
  padding: 0.5rem 1.5rem;
}

.courses_section .course_card:hover .course_hover {
  top: 0;
}

.courses_section .course_card:hover .course_item {
  visibility: hidden;
}

.testimonial_section {
  padding: 4rem 0;
}

.testimonial_section .testimonial_heading {
  margin-bottom: 2rem;
}

.testimonial_section .testimonial_heading h2 {
  font-size: 2.3rem;
  font-weight: 600;
  line-height: 2rem;
  margin: 1rem 0;
}

.testimonial_section .testimonial_heading .description {
  font-size: 0.85rem;
  line-height: 1.3rem;
  font-weight: 400;
  text-align: center;
  margin: 1.6rem 0;
}

.testimonial_section .testimonial_item {
  background: linear-gradient(234.06deg, rgba(255, 255, 255, 0.2) 0%, rgba(255, 255, 255, 0.6) 100%);
  border: 2px solid rgba(255, 255, 255, 0.568);
  border-radius: 1rem;
  padding: 1rem;
  position: relative;
  margin-top: 3rem;
}

.testimonial_section .testimonial_item .quote {
  top: -0.9rem;
  right: 1.2rem;
  width: 2.5rem;
}

.testimonial_section .testimonial_item .quote img {
  width: 100%;
  height: auto;
}

.testimonial_section .testimonial_item .client_img {
  width: 25rem;
  margin-right: 1rem;
}

.testimonial_section .testimonial_item .client_img img {
  width: 100%;
  height: auto;
  border-radius: 0.8rem;
}

.testimonial_section .testimonial_item .review .name {
  font-size: 1rem;
  color: #662d91;
  font-weight: 600;
  line-height: 1.4rem;
  text-transform: capitalize;
}

.testimonial_section .testimonial_item .review .position,
.testimonial_section .testimonial_item .review .comments {
  font-size: 0.75rem;
  color: #bea7cf;
}

.testimonial_section .testimonial_item .review .comments {
  margin-top: 1rem;
}

.testimonial_section .middle {
  margin-top: 5rem;
}

.countdown_section {
  padding: 1rem 0;
}

.countdown_section .countdown_inner {
  padding: 2rem 4rem;
  -webkit-box-shadow: 0px 6px 25px -10px rgba(102, 45, 145, 0.39);
          box-shadow: 0px 6px 25px -10px rgba(102, 45, 145, 0.39);
}

.countdown_section .countdown_inner .icon_img {
  width: 3rem;
  margin-right: 1rem;
}

.countdown_section .countdown_inner .icon_img img {
  width: 100%;
  height: auto;
}

.countdown_section .countdown_inner .info h2 {
  font-size: 2rem;
  line-height: 2rem;
  font-weight: 600;
  color: #662d91;
}

.countdown_section .countdown_inner .info p {
  font-size: 0.75rem;
  font-weight: 400;
  color: #858585;
  list-style: 1.7rem;
}

.newsletter_section {
  padding: 4rem 0;
}

.newsletter_section .newsletter_heading {
  margin-bottom: 2rem;
}

.newsletter_section .newsletter_heading h2 {
  font-size: 2.3rem;
  font-weight: 600;
  line-height: 2rem;
  margin: 1rem 0;
}

.newsletter_section .newsletter_heading .description {
  font-size: 0.85rem;
  line-height: 1.3rem;
  font-weight: 400;
  text-align: center;
  margin: 1.6rem 0;
}

.newsletter_section .newsletter_col {
  margin-left: 25%;
}

.newsletter_section .newsletter_col .newsletter_feild {
  margin-top: 1rem;
}

.newsletter_section .newsletter_col .newsletter_feild .newsletter_input {
  border-radius: 1rem 0 0 1rem;
  padding: 0.6rem 2rem;
  background: linear-gradient(234.06deg, rgba(255, 255, 255, 0.2) 0%, rgba(255, 255, 255, 0.6) 100%);
  border: 2px solid #ffffff;
}

.newsletter_section .newsletter_col .newsletter_feild .newsletter_input:focus {
  -webkit-box-shadow: none;
          box-shadow: none;
}

.newsletter_section .newsletter_col .newsletter_feild .newsletter_btn {
  border-radius: 0 1rem 1rem 0;
  padding: 0.6rem 2rem;
  font-weight: 600;
  letter-spacing: 1px;
}

.newsletter_section .newsletter_col .newsletter_feild .newsletter_btn:focus {
  -webkit-box-shadow: none;
          box-shadow: none;
}

.newsletter_section .newsletter_col .newsletter_feild ::-webkit-input-placeholder {
  color: #662d91;
  font-weight: 600;
  font-family: "Montserrat", sans-serif;
}

.newsletter_section .newsletter_col .newsletter_feild :-ms-input-placeholder {
  color: #662d91;
  font-weight: 600;
  font-family: "Montserrat", sans-serif;
}

.newsletter_section .newsletter_col .newsletter_feild ::-ms-input-placeholder {
  color: #662d91;
  font-weight: 600;
  font-family: "Montserrat", sans-serif;
}

.newsletter_section .newsletter_col .newsletter_feild ::placeholder {
  color: #662d91;
  font-weight: 600;
  font-family: "Montserrat", sans-serif;
}
/*# sourceMappingURL=all-home-website.css.map */
</style>
