<template>
<div>
    <main class="dashboard_main">
        <section class="dashboad tork-d-flex">
            <div ref="leftSidebar" class="left_sidebar">

                    <dashboard-navs></dashboard-navs>
            </div>
            <div class="dashboad_body">
                <!-- Header -->
                <div class="header">
                    <div class="title tork-d-flex tork-justify-c-space-between tork-items-center">
                        <h2>Dashboad</h2>
                        <button  id="togglerBtnh" class="toggler tork-btn" @click="showMenu">
                            <span class="icon-th-menu"></span>
                        </button>
                    </div>
                    <div class="tork-d-flex tork-justify-c-space-between tork-flex-wrap">
                        <div class="search_input">
                            <input type="text" class="tork-form-control" placeholder="Search Here">
                            <span class="icon-search"></span>
                        </div>
                        <div class="notificaton">
                            <div class="alert_icon">
                                <span class="icon-alarm"></span>
                                <span class="badge">15</span>
                            </div>
                            <div class="alert_icon">
                                <span class="icon-envelope"></span>
                                <span class="badge">05</span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- main body content -->

            </div>
        </section>
    </main>
    <div class="circle_1"></div>
    <div class="circle_2"></div>
</div>
</template>

<script>
export default {
    name: "home",

    created(){
        if(!User.loggedIn()) {
            this.$router.push('/auth/login')
        }
    },

    date(){
        return{

        }
    },
    methods:{
        showMenu() {
            this.$refs.leftSidebar.classList.toggle('leftSidebar');
        }

    }


}
</script>


