<template>
<div>

</div>

     <!-- <button @click="startMeeting">Join Meeting</button> -->
</template>

<script>



import { ZoomMtg } from "../../../../node_modules/@zoomus/websdk";
export default{

  created () {
    if(!User.loggedIn()){
        this.$router.push('/auth/login')
    }
    this.userName = User.name();
    ZoomMtg.setZoomJSLib('https://source.zoom.us/1.9.5/lib', '/av');
    ZoomMtg.preLoadWasm();
    ZoomMtg.prepareJssdk();
    this.meetingNumber =  this.$route.query.zoom_id
    this.passWord = this.$route.query.zoom_password
    this.leaveUrl = baseUrl+"/watch-class/"+this.$route.query.class_id;
    axios.post('/api/zoom-signature',this.form)
        .then(response => {
            this.signature = response.data.signature;
            this.apiKey = response.data.apiKey;
            this.startMeeting();
        })
        .catch(error => this.errors =
            Toast.fire({
                icon: 'error',
                title: 'something went wrong!'
            })
        )
  },

  mounted() {
    ZoomMtg.inMeetingServiceListener("onUserJoin", (data) => {
        console.log("inMeetingServiceListener onUserJoin", data);
    });

  },

  data () {
    return {
        apiKey: "",
        leaveUrl: "",
        meetingNumber:"",
        passWord:"",
        role: 1,
        userEmail: "",
        userName: "",
        signature:'',
        form:{
            meeting_number: this.$route.query.zoom_id,
        },
    }
  },

  methods: {
    startMeeting() {
        document.getElementById("zmmtg-root").style.display = "block";

        ZoomMtg.init({
            leaveUrl: this.leaveUrl,
            isSupportAV: false,
            success: (success) => {
                console.log(success);
                ZoomMtg.join({
                    meetingNumber: this.meetingNumber,
                    userName: this.userName,
                    signature: this.signature,
                    apiKey: this.apiKey,
                    userEmail: this.userEmail,
                    passWord: this.passWord,
                    success: (success) => {
                    console.log(success);
                    },
                    error: (error) => {
                    console.log(error);
                    }
                });
            },
            error: (error) => {
                console.log(error);
            }
        });
    }
  }
}
</script>


<style scoped>

body {
    /* display: none !important; */
  overflow: hidden !important;
}
#zmmtg-root {
  display: block;
}
</style>
