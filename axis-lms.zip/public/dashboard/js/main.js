// Progress bar
intializeTorkProgressBar({
  progressClass: ".progress_done"
});

// Drag and drop
// intializeDragDrop({
//   itemElement: ".q_item",
//   containerElement: ".question_container",
//   containerTargetUniqueElement: ".container_target",
//   containerSourceUniqueElement: ".container_source",
// });
