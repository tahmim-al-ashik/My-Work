// Progress bar
intializeTorkProgressBar({
  progressClass: ".progress_done",
});
